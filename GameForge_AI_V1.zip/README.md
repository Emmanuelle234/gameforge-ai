# GameForge AI — Version 1

This is the first frontend prototype of the planned browser-based 3D game creation platform.

## Files
- index.html — main website
- style.css — design and responsive layout
- app.js — prototype game generation interaction

## What Version 1 does
- Lets a user describe a game.
- Lets the user choose genre, world and visual style.
- Creates a simulated project workspace.
- Shows a lightweight fake 3D game preview.
- Provides builder categories for World, Player, Vehicles, NPCs, Missions, Economy and Lighting.

## Important
This version does NOT yet use a real AI model or generate real 3D assets. It is the frontend foundation.

## Next versions
1. Connect a real AI backend.
2. Connect PlayCanvas for real 3D scenes.
3. Generate/load real GLB assets.
4. Save user projects.
5. Add accounts.
6. Add publishing/export.

The PlayCanvas Engine is an open-source browser 3D engine, and its Editor is browser-based.
