const createBtn = document.getElementById("createBtn");
const workspace = document.getElementById("workspace");
const loading = document.getElementById("loading");
const projectTitle = document.getElementById("projectTitle");
const projectDescription = document.getElementById("projectDescription");
const gameView = document.getElementById("gameView");
const playBtn = document.getElementById("playBtn");

function makeTitle(prompt){
  if(prompt.toLowerCase().includes("lagos")) return "Street Legends: Lagos";
  const words = prompt.replace(/[^a-zA-Z0-9 ]/g,"").trim().split(/\s+/).slice(0,4);
  return words.length ? words.map(w=>w[0].toUpperCase()+w.slice(1)).join(" ") : "My 3D Game";
}

createBtn.addEventListener("click", () => {
  const prompt = document.getElementById("gamePrompt").value.trim();
  const genre = document.getElementById("genre").value;
  const world = document.getElementById("world").value;
  const style = document.getElementById("style").value;

  if(!prompt){
    alert("Describe the game you want first.");
    return;
  }

  createBtn.disabled = true;
  createBtn.textContent = "⏳ BUILDING PROTOTYPE...";
  workspace.classList.remove("hidden");
  loading.classList.remove("hidden");

  projectTitle.textContent = makeTitle(prompt);
  projectDescription.textContent = `${genre} • ${world} • ${style}`;

  setTimeout(() => {
    loading.classList.add("hidden");
    createBtn.disabled = false;
    createBtn.textContent = "✨ CREATE 3D GAME";
    workspace.scrollIntoView({behavior:"smooth"});
  }, 1400);
});

playBtn.addEventListener("click", () => {
  const player = document.querySelector(".player");
  let x = 50;
  let direction = 1;
  let ticks = 0;
  const timer = setInterval(() => {
    x += direction * 0.7;
    if(x > 65 || x < 35) direction *= -1;
    player.style.left = x + "%";
    ticks++;
    if(ticks > 140) clearInterval(timer);
  }, 20);
});

document.querySelectorAll(".tool").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tool").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
  });
});

document.getElementById("demoBtn").addEventListener("click", () => {
  document.getElementById("gamePrompt").value =
    "Create a realistic Lagos open-world game with a young Nigerian character, cars, shops, pedestrians, police and story missions.";
  document.getElementById("gamePrompt").focus();
});
